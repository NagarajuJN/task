# 1. Take values of length and breadth of a rectangle from user and check if it is square or not.


l=int(input(" enter the length of rectangle:"))
b=int(input(" enter the breadth of  rectangle:"))
if l==b:
    print(" its square:")
else:
    print("its not a square:")