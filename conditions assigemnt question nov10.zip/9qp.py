# 9. Modify the above question to allow student to sit if he/she has medical cause. Ask user if he/she has medical cause or not ( 'Y' or 'N' )



x=int(input('Number of classes held :'))
y=int(input('Number of classes attended:'))
attendence=(y/(x))*100
print('attendence of the student is in precentage',attendence)
medical_causes=input('he/she has medical cause Yes or NO:' )
if medical_causes== 'Yes':
    print(' he/she allowed to  sit ')

else:
    print(' not  allowed to  sit ')

