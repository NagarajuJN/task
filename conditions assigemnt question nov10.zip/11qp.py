# 11. How to find the greatest amoung three numbers?


x = 2
y = 5
z = 0
if x>y and y>z:
    print(  ' greatest is ',x)
elif y>z and y>x:
    print(' greatest is',y)
else:
    print('is greatest',z)
