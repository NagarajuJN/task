# 3. A shop will give discount of 10% if the cost of purchased quantity is more than 1000.
# Ask user for quantity
# Suppose, one unit will cost 100.
# # Judge and print total cost for user.



quantity=int(input(' enter the cost for the quantity:'))
if quantity>1000:
    x=quantity*.1
    totoal_discount_quantity=(quantity-x)
    print(' dicount cost:',x)
    print('totoal dcost for user',totoal_discount_quantity)
else:
    print( "total cost",quantity)



























