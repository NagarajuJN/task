# 12. How to find the smallest amoung three numbers?


x = 2
y = 5
z = 0
if x<y and y<z:
    print('x is  smallest')
elif y<z and y<x:
    print(' y is  smallest')
else:
    print('z is  smallest')