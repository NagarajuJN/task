# 4. A company decided to give bonus of 5% to employee if his/her year of service is more than 5 years.
# Ask user for their salary and year of service and print the net bonus amount.


salary=int(input(" enter the employee salary:"))
service=int(input(" enter the years  of  service:"))
if service>5:
    bonus=.05*salary
    print("net Bouns is :",bonus)
else:
    print("no bonus")
