# 6. Take input of age of 3 people by user and determine oldest and youngest among them.


a=int(input('enter the age of first person:'))
b=int(input('enter the age of 2nd person:'))
c=int(input('enter the age of 3rd person:'))
if a>b and a>c:
    print('a is oldest:',a)
elif b>c and b>a:
    print('b is oldest:',b)
elif c>a and c>b:
    print('c is oldest:',c)

if a<b and a<c:
    print('a is smalest:',a)
elif b<c and b<a:
    print('b is  smalest:',b)
elif c<a and c<b:
    print('c is  smalest:',c)




