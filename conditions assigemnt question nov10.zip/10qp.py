# 10. If
# x = 2
# y = /5
# z = 0
# then find values of the following expressions:
# a. x == 2
# b. x != 5
# c. x != 5 && y >= 5
# d. z != 0 || x == 2
# e. !(y < 10)
x = 2
y = 5
z = 0
# print( x == 2)
# print(x != 5)
# print(x != 5  and y >= 5)
# print(z != 0 or x == 2)

if  x==2:
    print(True)
else:
    print(False)
if x!=5:
    print(True)
else:
    print(False)
if x!=5 and y >= 5:
    print(True)
else:
    print(False)
if z != 0 or x == 2:
    print(True)

else:
    print(False)
if y >10:
    print(True)
else:
    print(False)