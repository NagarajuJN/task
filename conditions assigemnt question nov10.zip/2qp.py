# 2. Take two int values from user and print greatest among them.


num1=int(input("enter the 1st numbers:"))
num2=int(input("enter the 2nd numbers:"))
if num1>num2 :
    print(num1 ,'is  greatest')
else :
    print(num2,' is greatest')
