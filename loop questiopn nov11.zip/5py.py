# 5.for numbers from 1 to 20
#    check if the number is divisible by 2,3 or 5
#    or all the three
#    or none of the three
#    (should work for any range of numbers)
for num in range(1, 21):
    if num % 2 == 0 and num % 3 == 0  and num % 5 == 0:
        print("given numbers are divisible by all three numbers:",num)
    elif  num % 5 == 0:
                print(" numbers is divisible 5 :",num)
    elif num % 2== 0:
                print(" numbers is divisible 2:",num)
    elif num % 3 == 0:
                print(" numbers is divisible 3:", num)
else:
    print(" none given numbers are divisible by all three numbers:")



