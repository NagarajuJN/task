# 1.print the sum and product from 1 to 20.
x= 0
product=1
for num in range(1, 20+1):
    sum = x+num
    product=product*num
print("sum from 1to 20 is:",sum )
print("product of 1 to 20 is:",product)