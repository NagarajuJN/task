# 2.print the numbers which is not divisible by 3 , from 1 to 20.


for num in range(1,21):
    if num%3!=0:
        print(num)