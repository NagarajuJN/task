# # 4.print average of numbers from 1 to 20 (should work for any numbers)

a=int(input(">>>"))
b=int(input(">>>"))

x=range(a,b+1)
i= 0
for num in x:
    i += num
avg1 = i / len(x)
print("Average is: ", avg1)






#  num_list=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
# # res1 = 0
# # for num in num_list:
# #     res1 += num
# # avg1 = res1 / len(num_list)
# # print("Average is: ", avg1)