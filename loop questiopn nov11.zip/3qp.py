# 3.print even numbers between 1 and 20.

for num in range(1,21):
    if num%2==0:

        print(num)
